"""Data SINTETIS berskema Volve (hanya untuk smoke-test pipeline/demo).
JANGAN dipakai sebagai bukti performa di laporan. Ganti dengan data Volve asli."""
import numpy as np, pandas as pd

def make_synthetic(n_wells=6, seed=7):
    rng = np.random.default_rng(seed)
    rows = []
    for w in range(n_wells):
        n = int(rng.integers(900, 1400)); t = np.arange(n)
        qi, di, b = rng.uniform(1500, 4000), rng.uniform(.003, .008), rng.uniform(.3, .9)
        base = qi / (1 + b * di * t) ** (1 / b)
        if rng.random() < .5:  # workover / choke-up: lonjakan yang tak bisa diprediksi dari histori
            k = int(rng.integers(n // 3, 2 * n // 3)); base[k:] *= rng.uniform(1.2, 1.4)
        up = np.ones(n)
        for _ in range(int(rng.integers(3, 7))):  # shut-in
            s = int(rng.integers(60, n - 60)); d = int(rng.integers(5, 40)); up[s:s + d] = 0
        wc = 1 / (1 + np.exp(-(t - rng.uniform(.4, .8) * n) / (n / 8))) * rng.uniform(.5, .9)
        oil = base * up * rng.lognormal(0, .04, n)
        liq = oil / (1 - wc + 1e-3); wat = liq - oil
        gor = rng.uniform(100, 200) * (1 + t / n * .5)
        whp = 60 * np.exp(-t / (n * 1.5)) * rng.lognormal(0, .03, n) * (up > 0)
        rows.append(pd.DataFrame({
            "date": pd.Timestamp("2008-03-01") + pd.to_timedelta(t, "D"), "well": f"SYN-{w+1}",
            "hours": 24 * up, "whp": whp, "choke": np.clip(60 + rng.normal(0, 3, n).cumsum() * .1, 20, 100) * (up > 0),
            "oil": oil, "gas": oil * gor, "wat": wat}))
    return pd.concat(rows, ignore_index=True)
