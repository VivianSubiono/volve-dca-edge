"""Pipeline: data -> fitur -> XGBoost -> evaluasi vs Arps -> TreeSHAP -> ONNX -> artefak untuk web (public/).

TARGET MODEL = RASIO, bukan laju absolut:
    rasio = mean(oil[t+1..t+30]) / mean(oil[t-29..t])      # produksi 30 hari ke depan / rata-rata 30 hari saat ini
    laju_prediksi = rasio_prediksi * mean(oil[t-29..t])    # dikonversi balik ke sm3/hari (dipakai untuk semua metrik)
Rasio = 1 berarti sama dengan persistence; < 1 menurun; > 1 naik (mis. setelah workover/buka choke)."""
import json, sys, time, pathlib, warnings
import numpy as np, pandas as pd, xgboost as xgb, onnxruntime as ort
from scipy.optimize import curve_fit
from onnxmltools import convert_xgboost
from onnxmltools.convert.common.data_types import FloatTensorType
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from generate_synthetic import make_synthetic
warnings.filterwarnings("ignore")

ROOT = pathlib.Path(__file__).resolve().parents[1]
H, WIN, TRAIN_FRAC, STRIDE = 30, 180, .75, 5
RATIO_MAX = 3.0   # batas atas rasio target (menahan outlier lonjakan)
MIN_M30 = 5       # baris dengan rata-rata 30 hari <= ini dibuang, jadi pembagi tidak pernah nol
FEATS = ["oil_m7_m30", "oil_m30_m90", "oil_d1_m30", "wc7", "wc_delta", "log_gor7", "gor_ratio",
         "whp7", "whp_ratio", "choke7", "uptime7", "uptime30", "log_days", "log_m30"]

def load_volve(path):
    """Skema sheet 'Daily Production Data' Volve (berdasarkan ingatan; VERIFIKASI nama kolom vs file Anda)."""
    d = pd.read_excel(path, sheet_name="Daily Production Data")
    if "WELL_TYPE" in d: d = d[d.WELL_TYPE == "OP"]
    d = d.rename(columns={"DATEPRD": "date", "NPD_WELL_BORE_NAME": "well", "ON_STREAM_HRS": "hours",
        "AVG_WHP_P": "whp", "AVG_CHOKE_SIZE_P": "choke", "BORE_OIL_VOL": "oil", "BORE_GAS_VOL": "gas", "BORE_WAT_VOL": "wat"})
    return d[["date", "well", "hours", "whp", "choke", "oil", "gas", "wat"]]

def prep_well(g):
    g = g.drop_duplicates("date").set_index("date").sort_index()
    g = g.reindex(pd.date_range(g.index.min(), g.index.max()))
    for c in ["oil", "gas", "wat", "hours"]: g[c] = g[c].fillna(0)   # ASUMSI: gap = shut-in
    for c in ["whp", "choke"]: g[c] = g[c].ffill().bfill().fillna(0)
    return g

def feats(g):
    r = lambda s, w: s.rolling(w, min_periods=1).mean()
    o = g.oil; m7, m30, m90 = r(o, 7), r(o, 30), r(o, 90)
    wc7 = r(g.wat, 7) / (r(g.oil + g.wat, 7) + 1e-6); wc30 = r(g.wat, 30) / (r(g.oil + g.wat, 30) + 1e-6)
    gor7, gor30 = r(g.gas, 7) / (m7 + 1e-6), r(g.gas, 30) / (m30 + 1e-6)
    f = pd.DataFrame({"oil_m7_m30": m7 / (m30 + 1), "oil_m30_m90": m30 / (m90 + 1), "oil_d1_m30": o / (m30 + 1),
        "wc7": wc7, "wc_delta": wc7 - wc30, "log_gor7": np.log1p(gor7), "gor_ratio": (gor7 / (gor30 + 1e-6)).clip(0, 5),
        "whp7": r(g.whp, 7), "whp_ratio": (r(g.whp, 7) / (r(g.whp, 30) + 1e-6)).clip(0, 5), "choke7": r(g.choke, 7),
        "uptime7": r(g.hours, 7) / 24, "uptime30": r(g.hours, 30) / 24,
        "log_days": np.log1p(np.arange(len(g))), "log_m30": np.log1p(m30)}, index=g.index).fillna(0)
    f["m30"] = m30; f["y"] = o.rolling(H).mean().shift(-H)   # rata-rata t+1..t+H
    return f

def to_ratio(y, m30): return (y / m30).clip(0, RATIO_MAX)   # target latih: 30 hari ke depan / 30 hari saat ini
def from_ratio(r, m30): return r * m30                       # konversi balik rasio -> laju (sm3/hari)

def arps(t, qi, di, b): return qi / np.power(1 + b * di * t, 1 / b)
def arps_fit(hist):
    t, m = np.arange(len(hist)), hist > 0
    if m.sum() < 20: return None
    try:
        return curve_fit(arps, t[m], hist[m], p0=[hist[m][:10].mean(), .005, .5],
                         bounds=([0, 1e-6, .01], [hist.max() * 3, .1, 2.]), maxfev=2000)[0]
    except Exception: return None

def main():
    xl = next((ROOT / "data/raw").glob("*.xlsx"), None)
    src = "volve" if xl else "synthetic"
    df = load_volve(xl) if xl else make_synthetic()
    print("data source:", src)
    wells = {w: prep_well(g) for w, g in df.groupby("well")}
    tr, te = [], []
    for w, g in wells.items():
        f = feats(g); f["well"] = w; f["t"] = np.arange(len(g))
        f = f[(f.m30 > MIN_M30) & f.y.notna()]; cut = int(TRAIN_FRAC * len(g))
        tr.append(f[f.t <= cut - H]); te.append(f[(f.t >= cut) & (f.t >= 60)])   # gap H hari: cegah leakage target
    tr, te = pd.concat(tr), pd.concat(te)
    # target relatif (rasio): pohon tidak bisa ekstrapolasi skala laju, tapi rasio berskala sama antar sumur
    model = xgb.XGBRegressor(n_estimators=200, max_depth=3, learning_rate=.05, subsample=.8, colsample_bytree=.8,
                             min_child_weight=5, random_state=0)
    model.fit(tr[FEATS].values.astype(np.float32), to_ratio(tr.y, tr.m30))

    # --- evaluasi (semua metode pada titik yang sama) ---
    ev = te.iloc[::STRIDE].copy()
    ev["r_xgb"] = model.predict(ev[FEATS].values.astype(np.float32))   # rasio prediksi
    ev["p_xgb"] = from_ratio(ev.r_xgb, ev.m30)                           # -> laju prediksi (sm3/hari)
    ev["p_naive"] = ev.m30
    pa = []
    for _, row in ev.iterrows():
        oil = wells[row.well].oil.values; t = int(row.t); hist = oil[max(0, t - WIN + 1):t + 1]
        p = arps_fit(hist)
        pa.append(arps(np.arange(len(hist), len(hist) + H), *p).mean() if p is not None else row.m30)
    ev["p_arps"] = pa
    def met(p): e = p - ev.y; return dict(MAE=round(float(e.abs().mean()), 2), RMSE=round(float(np.sqrt((e**2).mean())), 2),
                                          WAPE=round(float(e.abs().sum() / ev.y.sum()), 4))
    r_true = ev.y / ev.m30   # rasio aktual (tanpa clip) untuk diagnostik ruang-rasio
    metrics = {"data_source": src, "horizon_days": H,
               "target": {"definition": "rata-rata laju minyak 30 hari ke depan / rata-rata 30 hari saat ini", "ratio_clip_max": RATIO_MAX,
                          "ratio_MAE": {"Persistence (rasio = 1)": round(float((r_true - 1).abs().mean()), 4),
                                        "XGBoost": round(float((ev.r_xgb - r_true).abs().mean()), 4)}}, "n_train": int(len(tr)), "n_test_eval": int(len(ev)),
               "models": {"Persistence (mean 30d)": met(ev.p_naive), f"Arps hyperbolic (fit {WIN}d)": met(ev.p_arps),
                          "XGBoost (lag+rolling)": met(ev.p_xgb)},
               "wape_per_well": {w: {"arps": round(float((d.p_arps-d.y).abs().sum()/d.y.sum()), 4),
                                     "xgb": round(float((d.p_xgb-d.y).abs().sum()/d.y.sum()), 4)} for w, d in ev.groupby("well")}}

    # --- ONNX ---
    onx = convert_xgboost(model, initial_types=[("input", FloatTensorType([None, len(FEATS)]))], target_opset=15)
    mp = ROOT / "public/model.onnx"; mp.write_bytes(onx.SerializeToString())
    sess = ort.InferenceSession(str(mp)); X = ev[FEATS].values.astype(np.float32)
    diff = float(np.abs(sess.run(None, {"input": X})[0].ravel() - model.predict(X)).max())
    x1 = X[:1]; lat = []
    for _ in range(300): t0 = time.perf_counter(); sess.run(None, {"input": x1}); lat.append((time.perf_counter() - t0) * 1e3)
    metrics["efficiency"] = {"model_size_MB": round(mp.stat().st_size / 1e6, 4), "latency_ms_p50_native_ort": round(float(np.median(lat)), 3),
                             "onnx_vs_xgb_max_abs_diff": diff}

    # --- TreeSHAP (xgboost pred_contribs, satuan sm3/d) + sampel web ---
    bst = model.get_booster(); C = bst.predict(xgb.DMatrix(X), pred_contribs=True)
    metrics["global_shap_mean_abs"] = {f: round(float(np.abs(C[:, i] * ev.m30.values).mean()), 3) for i, f in enumerate(FEATS)}
    pick = [d.index[len(d) // 3] for _, d in te.groupby("well")][:4]
    pick += list(te[(te.uptime30 < .8) & (te.m30 > 5)].index[::90][:2])
    samples = []
    for ix in pick:
        row = te.loc[[ix]].iloc[0]; oil = wells[row.well].oil; t = int(row.t)
        hist = oil.values[max(0, t - WIN + 1):t + 1]; p = arps_fit(hist); fx = row[FEATS].values.astype(np.float32)
        c = bst.predict(xgb.DMatrix(fx[None]), pred_contribs=True)[0]; sc = float(row.m30)   # kontribusi SHAP (ruang rasio) x m30 -> sm3/hari
        samples.append({"id": f"{row.well} | t+{H}d dari {oil.index[t].date()}", "well": row.well,
            "features": [float(v) for v in fx], "m30": round(float(row.m30), 4), "ratio_pred": round(float(model.predict(fx[None])[0]), 5),
            "ratio_actual": round(float(row.y / row.m30), 5), "history": [round(float(v), 1) for v in oil.values[t-119:t+1]],
            "future_actual": [round(float(v), 1) for v in oil.values[t+1:t+H+1]], "actual_mean": round(float(row.y), 1),
            "arps_mean": round(float(arps(np.arange(len(hist), len(hist)+H), *p).mean()), 1) if p is not None else None,
            "shap": sorted([{"f": f, "v": round(float(c[j] * sc), 2)} for j, f in enumerate(FEATS)], key=lambda z: -abs(z["v"])),
            "shap_base": round(float(c[-1] * sc), 2)})
    (ROOT / "public/samples.json").write_text(json.dumps({"feature_names": FEATS, "samples": samples}))
    (ROOT / "public/metrics.json").write_text(json.dumps(metrics, indent=1))
    print(json.dumps(metrics, indent=1)); print("samples:", len(samples))

if __name__ == "__main__": main()
